// PayTech appelle cette adresse quand un paiement est réussi
import { getStore } from '@netlify/blobs';
import { createHash } from 'node:crypto';
const sha = (t) => createHash('sha256').update(String(t)).digest('hex');
export default async (req) => {
  let p = {};
  const raw = await req.text();
  try { p = JSON.parse(raw); } catch { p = Object.fromEntries(new URLSearchParams(raw)); }
  const ok = p.api_key_sha256 === sha(process.env.PAYTECH_API_KEY) &&
             p.api_secret_sha256 === sha(process.env.PAYTECH_API_SECRET);
  if (!ok) return new Response('refuse', { status: 403 });
  if (p.type_event === 'sale_complete' && p.ref_command) {
    await getStore('paiements').set(p.ref_command, '1');
  }
  return new Response('OK');
};
