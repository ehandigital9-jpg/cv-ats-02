// Le site demande ici si la commande a bien été payée
import { getStore } from '@netlify/blobs';
export default async (req) => {
  const ref = new URL(req.url).searchParams.get('ref') || '';
  if (!/^[\w-]+$/.test(ref)) return Response.json({ ok: false });
  const v = await getStore('paiements').get(ref);
  return Response.json({ ok: v === '1' });
};
