// Crée le paiement PayTech (Wave / Orange Money) et renvoie le lien de paiement
export default async (req) => {
  const site = process.env.SITE_URL || new URL(req.url).origin;
  const ref = 'CV' + Date.now() + Math.random().toString(36).slice(2, 7);
  try {
    const r = await fetch('https://paytech.sn/api/payment/request-payment', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json',
        'API_KEY': process.env.PAYTECH_API_KEY, 'API_SECRET': process.env.PAYTECH_API_SECRET },
      body: JSON.stringify({
        item_name: 'Verificateur CV ATS - version complete',
        item_price: Number(process.env.PRIX || 500),
        currency: 'XOF',
        ref_command: ref,
        command_name: 'Acces complet CV ATS',
        env: process.env.PAYTECH_ENV || 'prod',   // mettre "test" pour essayer sans payer
        ipn_url: site + '/.netlify/functions/paytech-ipn',
        success_url: site + '/?paid=1&ref=' + ref,
        cancel_url: site + '/?paid=0',
        target_payment: 'Wave, Orange Money'
      })
    });
    const d = await r.json();
    if (d.success !== 1 || !d.redirect_url) return Response.json({ error: d.message || 'Erreur PayTech' }, { status: 502 });
    return Response.json({ url: d.redirect_url, ref });
  } catch (e) { return Response.json({ error: 'Erreur serveur' }, { status: 500 }); }
};
